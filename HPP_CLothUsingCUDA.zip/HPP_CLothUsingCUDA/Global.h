//Windowing and standard Headers
#include <Windows.h>
#include <stdio.h>
#include <string>

//OpenGL headers
#include <C:/glew-2.1.0/include/GL/glew.h>
#include <gl/GL.h>

//CUDA headers
#include <cuda_gl_interop.h>
#include <cuda_runtime.h>
#include <cuda.h>
#include <device_launch_parameters.h>

//local headers
#include "vmath.h"
#include "resource.h"

// Link libraries
#pragma comment(lib, "glew32.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "winmm.lib")  
#pragma comment(lib, "cudart.lib") 
#pragma comment(lib, "freetype.lib")

// Defines
#define WIN_WIDTH  800
#define WIN_HEIGHT 600

#define PRIMITIVE_RESTART 0xffffff
#define MY_ARRAY_SIZE gMeshWidth * gMeshHeight * 4

using namespace vmath;

enum {
	CLOTH_ATTRIBUTE_POSITION = 0,
	CLOTH_ATTRIBUTE_COLOR,
	CLOTH_ATTRIBUTE_NORMAL,
	CLOTH_ATTRIBUTE_TEXCOORD
};


//global file
extern FILE* gpFile;


// Global function declaration
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);