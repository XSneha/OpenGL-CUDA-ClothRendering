#pragma once

#include <map>
#include <string>

typedef enum _OGL_ATTRIBUTES
{
	FONT_ATTRIBUTE_POSITION = 0,
	FONT_ATTRIBUTE_COLOR,
	FONT_ATTRIBUTE_NORMAL,
	FONT_ATTRIBUTE_TEXTURE
}attributes;

// function prototypes for Fonts
void InitializeFont(void);
void RenderFont(std::string text, GLfloat x, GLfloat y, GLfloat scale, vec3 color, float winWidth, float winHeight);
void UnInitializeFont(void);


