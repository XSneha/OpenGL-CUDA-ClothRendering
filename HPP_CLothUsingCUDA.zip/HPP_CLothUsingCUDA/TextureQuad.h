#include<stdio.h>
#include"vmath.h"

void InitializeQuadWithTexture();
void UnInitializeQuadWithTexture();
void RenderQuadWithTexture(vmath::mat4 perspectiveProjectionMatrix, float alpha , int scene);

