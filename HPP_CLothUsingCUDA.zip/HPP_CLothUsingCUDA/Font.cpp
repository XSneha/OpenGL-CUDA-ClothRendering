// headers 
#include <Windows.h>
#include <stdio.h>
#include <gl/glew.h>
#include <gl/GL.h>
#include <map>
#include <string>

#include <ft2build.h>
#include FT_FREETYPE_H

#include <freetype/fttypes.h>
#include <freetype/fterrors.h>

#include "vmath.h"
//#include "FontRendering2.h"

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glew32.lib")
#pragma comment(lib, "freetype.lib")

// libraries
#pragma comment(lib,"freetype.lib")

using namespace std;
using namespace vmath;

FILE* gpFontFile = NULL;

struct Character {
	unsigned int TextureID;  // ID handle of the glyph texture
	ivec2   Size;       // Size of glyph
	ivec2   Bearing;    // Offset from baseline to left/top of glyph
	unsigned int Advance;    // Offset to advance to next glyph
};

std::map<char, Character> Characters;

GLuint fontVextexShaderObject;
GLuint fontFragmentShaderObject;
GLuint fontShaderProgramObject;
GLuint vaoFont;
GLuint vboFont;


void InitializeFont(void)
{
	void UnInitialize(void);
	BOOL loadTexture(GLuint * texture, TCHAR imageResourceID[]);


	fopen_s(&gpFontFile, "FontLog.txt", "w");
	if (NULL == gpFontFile)
	{
		MessageBox(NULL, "ERROR :: Failed to create log file", "Error", MB_OK);
	}
	else {
		fprintf(gpFontFile, "INFO : Font file created!");
	}

	//Vertex shader
	fontVextexShaderObject = glCreateShader(GL_VERTEX_SHADER);
	const GLchar* vertexShaderSourceCode =
		"#version 450 core"\
		"\n"\
		"in vec4 vPosition;"\
		"out vec2 TexCoords;"\
		"uniform mat4 u_mvp_matrix;"\
		"void main()"\
		"{"\
		"	gl_Position = u_mvp_matrix * vec4(vPosition.xy, 0.0, 1.0);"\
		"	TexCoords = vPosition.zw;"
		"}";

	glShaderSource(fontVextexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);

	//compile shader
	glCompileShader(fontVextexShaderObject);

	GLint iInfoLength = 0;
	GLint iShaderCompiledStatus = 0;
	char* szInfoLog = NULL;

	glGetShaderiv(fontVextexShaderObject, GL_COMPILE_STATUS, &iShaderCompiledStatus);
	if (iShaderCompiledStatus == GL_FALSE)
	{
		glGetShaderiv(fontVextexShaderObject, GL_INFO_LOG_LENGTH, &iInfoLength);
		if (iInfoLength > 0)
		{
			szInfoLog = (char*)malloc(iInfoLength);
			if (szInfoLog != NULL)
			{
				GLsizei written;
				glGetShaderInfoLog(fontVextexShaderObject, iInfoLength, &written, szInfoLog);
				fprintf(gpFontFile, "ERROR  :: Vertex Shader Compilation Log:%s\n", szInfoLog);
				free(szInfoLog);
				UnInitialize();
				exit(0);
			}
		}
	}
	fprintf(gpFontFile, "INFO :: Vextex shader compilation done!");


	//Fragment shader
	fontFragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
	const GLchar* fragmentShaderSourceCode =
		"#version 450 core"\
		"\n"\
		"in vec2 TexCoords;"\
		"out vec4 color;"\
		"uniform sampler2D text;"\
		"uniform vec3 textColor;"\
		"void main()"\
		"{"\
		"vec2 uv=TexCoords.xy;"\
		"vec4 sampled = vec4(1.0,1.0,1.0,texture(text, uv).r);"\
		"color = vec4(textColor, 1.0) * sampled;"\
		"}";

	glShaderSource(fontFragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);

	//compile shader
	glCompileShader(fontFragmentShaderObject);
	glGetShaderiv(fontFragmentShaderObject, GL_COMPILE_STATUS, &iShaderCompiledStatus);
	if (iShaderCompiledStatus == GL_FALSE)
	{
		glGetShaderiv(fontFragmentShaderObject, GL_INFO_LOG_LENGTH, &iShaderCompiledStatus);
		if (iInfoLength > 0)
		{
			szInfoLog = (char*)malloc(iInfoLength);
			if (szInfoLog != NULL)
			{
				GLsizei written;
				glGetShaderInfoLog(fontFragmentShaderObject, iInfoLength, &written, szInfoLog);
				fprintf(gpFontFile, "ERROR :: Fragment shader compilation Log %s\n", szInfoLog);
				free(szInfoLog);
				UnInitialize();
				exit(0);
			}
		}
	}
	fprintf(gpFontFile, "INFO :: Fragment shader compilation done!");


	//shader program
	fontShaderProgramObject = glCreateProgram();

	glAttachShader(fontShaderProgramObject, fontVextexShaderObject);
	glAttachShader(fontShaderProgramObject, fontFragmentShaderObject);

	glLinkProgram(fontShaderProgramObject);
	GLint iShaderProgramLinkStatus = 0;
	glGetProgramiv(fontShaderProgramObject, GL_LINK_STATUS, &iShaderCompiledStatus);
	if (iShaderCompiledStatus == GL_FALSE)
	{
		glGetProgramiv(fontShaderProgramObject, GL_INFO_LOG_LENGTH, &iInfoLength);
		if (iInfoLength > 0)
		{
			szInfoLog = (char*)malloc(iInfoLength);
			if (szInfoLog != NULL)
			{
				GLsizei written;
				glGetProgramInfoLog(fontShaderProgramObject, iInfoLength, &written, szInfoLog);
				fprintf(gpFontFile, "ERROR :: Shader Program Link Status %s\n", szInfoLog);
				free(szInfoLog);
				UnInitialize();
				exit(0);
			}
		}
	}

	fprintf(gpFontFile, "INFO :: linking done!");

	FT_Library ft;
	if (FT_Init_FreeType(&ft)) {
		fprintf(gpFontFile, "ERROR::FREETYPE: Could not init FreeType Library");
	}
	
	FT_Face face;
	if (FT_New_Face(ft, "HarryP.ttf", 0, &face)) {
		fprintf(gpFontFile, "ERROR::FREETYPE: Failed to load font");

	}	
	FT_Set_Pixel_Sizes(face, 0, 40);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	for (GLubyte c = 0; c < 128; c++)
	{
		if (FT_Load_Char(face, c, FT_LOAD_RENDER))
		{
			fprintf(gpFontFile, "ERROR::FREETYTPE: Failed to load Glyph");
			continue;
		}
		GLuint texture;
		glGenTextures(1, &texture);
		glBindTexture(GL_TEXTURE_2D, texture);
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RED,
			face->glyph->bitmap.width,
			face->glyph->bitmap.rows,
			0,
			GL_RED,
			GL_UNSIGNED_BYTE,
			face->glyph->bitmap.buffer
		);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		Character character = {
			texture,
			vmath::ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows),
			vmath::ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top),
			(GLuint)face->glyph->advance.x
		};
		Characters.insert(std::pair<GLchar, Character>(c, character));
	}
	glBindTexture(GL_TEXTURE_2D, 0);

	FT_Done_Face(face);
	FT_Done_FreeType(ft);

	glGenVertexArrays(1, &vaoFont);
	glBindVertexArray(vaoFont);

	glGenBuffers(1, &vboFont);
	glBindBuffer(GL_ARRAY_BUFFER, vboFont);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), NULL);
	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}


// functions
void RenderFont(string text, GLfloat x, GLfloat y, GLfloat scale, vec3 color , float winWidth , float winHeight)
{
	mat4 Ortho = ortho(0.0f, 1000.0f, 0.0f, 1000.0f * (winWidth / winHeight), -1.0f, 1.0f);
	mat4 mvp = Ortho;
	glBindVertexArray(vaoFont);

	glUseProgram(fontShaderProgramObject);
	glUniform3fv(glGetUniformLocation(fontShaderProgramObject, "textColor"), 1, color);
	glUniformMatrix4fv(glGetUniformLocation(fontShaderProgramObject, "u_mvp_matrix"), 1, GL_FALSE, mvp);

	glActiveTexture(GL_TEXTURE0);

	string::const_iterator c;
	for (c = text.begin(); c != text.end(); c++)
	{
		Character ch = Characters[*c];

		GLfloat xpos = x + ch.Bearing[0] * scale;
		GLfloat ypos = y - (ch.Size[1] - ch.Bearing[1]) * (scale * 2.5f);

		GLfloat w = ch.Size[0] * scale;
		GLfloat h = ch.Size[1] * (scale * 2.5f);

		GLfloat vertices[6][4] = {
			{ xpos, ypos + h, 0.0, 0.0},
			{ xpos, ypos,     0.0, 1.0},
			{ xpos + w, ypos, 1.0, 1.0},
			{ xpos, ypos + h, 0.0, 0.0},
			{ xpos + w, ypos, 1.0, 1.0},
			{ xpos + w, ypos + h, 1.0,0.0}
		};

		glBindTexture(GL_TEXTURE_2D, ch.TextureID);
		glBindBuffer(GL_ARRAY_BUFFER, vboFont);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glDrawArrays(GL_TRIANGLES, 0, 6);

		x += (ch.Advance >> 6) * scale;

	}
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glUseProgram(0);
}


void UnInitializeFont() {



}