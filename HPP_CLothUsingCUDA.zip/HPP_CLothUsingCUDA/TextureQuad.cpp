#pragma once
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <gl/glew.h>
#include <gl/GL.h>
#include "vmath.h"
#include "resource.h"

enum {
	TX_ATTRIBUTE_POSITION = 0,
	TX_ATTRIBUTE_COLOR,
	TX_ATTRIBUTE_NORMAL,
	TX_ATTRIBUTE_TEXCOORD
};

//shader objects
GLint TX_gVertexShaderObject;
GLint TX_gFragmentShaderObject;
GLint TX_gShaderProgramObject;

//shader binding objects
GLuint TX_vao;
GLuint TX_vboPos;
GLuint TX_fdfoUniform;
GLuint TX_mvpMatrixUniform;
GLuint TX_texture1;
GLuint TX_texture2;
GLuint TX_texture3;

//color variables
GLuint TX_vboColor;
GLuint TX_vboTexture;
GLuint TX_textureSamplerUnifirm;

FILE* gpTextureFile = NULL;

// Convert image resource to image data
BOOL LoadGLTextureCredits(GLuint* texture, TCHAR imageResourceID[])
{
	// variables
	HBITMAP hBitmap = NULL;
	BITMAP bmp;
	BOOL bStatus = false;

	// data
	hBitmap = (HBITMAP)LoadImage(GetModuleHandle(NULL),
		imageResourceID,
		IMAGE_BITMAP,
		0, 0,
		LR_CREATEDIBSECTION
	);

	if (hBitmap)
	{
		bStatus = TRUE;
		GetObject(hBitmap, sizeof(BITMAP), &bmp);

		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		glGenTextures(1, texture);
		glBindTexture(GL_TEXTURE_2D, *texture);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bmp.bmWidth, bmp.bmHeight, 0, GL_BGR, GL_UNSIGNED_BYTE, bmp.bmBits);
		glGenerateMipmap(GL_TEXTURE_2D);

		glBindTexture(GL_TEXTURE_2D, 0);

		DeleteObject(hBitmap);
	}

	return bStatus;
}


void InitializeQuadWithTexture() {


	fopen_s(&gpTextureFile, "TextureLog.txt", "w");
	if (NULL == gpTextureFile)
	{
		MessageBox(NULL, "ERROR :: Failed to create log file", "Error", MB_OK);
	}
	else {
		fprintf(gpTextureFile, "INFO : Font file created!");
	}


	//Vertex shader
	//create shader
	TX_gVertexShaderObject = glCreateShader(GL_VERTEX_SHADER);

	//provide source object to shader
	const GLchar* vertexShaderSourceCode =
		"#version 440 core "\
		"\n"\
		"in vec4 vPosition;"\
		"in vec2 vTexcord;"\
		"in vec4 vColor;"\
		"uniform mat4 u_mvpMatrix;"\
		"out vec2 outTexcord;"\
		"out vec4 outColor;"\
		"void main(void)"\
		"{"\
		"gl_Position = u_mvpMatrix * vPosition;"\
		"outTexcord = vTexcord;"\
		"outColor = vColor;"\
		"}";

	glShaderSource(TX_gVertexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);

	//compile shader
	glCompileShader(TX_gVertexShaderObject);

	//shader compilation error checking here
	GLint infoLogLength = 0;
	GLint shaderCompilationStatus = 0;
	char* szBuffer = NULL;
	glGetShaderiv(TX_gVertexShaderObject, GL_COMPILE_STATUS, &shaderCompilationStatus);
	if (shaderCompilationStatus == GL_FALSE) {
		glGetShaderiv(TX_gVertexShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0) {
			szBuffer = (char*)malloc(infoLogLength);
			if (szBuffer != NULL) {
				GLint written;
				glGetShaderInfoLog(TX_gVertexShaderObject, infoLogLength, &written, szBuffer);
				//print log to file
				fprintf(gpTextureFile, "Vertex shader logs : %s \n", szBuffer);
				free(szBuffer);
			}
		}
	}

	//fragment shader
	//create shader
	TX_gFragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);

	//provide source object to shader
	const GLchar* fragmentShaderSourceCode =
		"#version 440 core "\
		"\n"\
		"in vec2 outTexcord;"\
		"in vec4 outColor;"\
		"uniform sampler2D u_texture_sampler;"\
		"uniform float alpha = 1.0;"\
		"uniform int keyPress;"\
		"out vec4 FragColor;"\
		"void main(void)"\
		"{"\
		"	FragColor = vec4(texture(u_texture_sampler,outTexcord).xyz,alpha);"\
		"}";


	glShaderSource(TX_gFragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);

	//compile shader
	glCompileShader(TX_gFragmentShaderObject);
	//shader compilation error checking here
	infoLogLength = 0;
	shaderCompilationStatus = 0;
	szBuffer = NULL;
	glGetShaderiv(TX_gFragmentShaderObject, GL_COMPILE_STATUS, &shaderCompilationStatus);
	if (shaderCompilationStatus == GL_FALSE) {
		glGetShaderiv(TX_gFragmentShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0) {
			szBuffer = (char*)malloc(infoLogLength);
			if (szBuffer != NULL) {
				GLint written;
				glGetShaderInfoLog(TX_gFragmentShaderObject, infoLogLength, &written, szBuffer);
				//print log to file
				fprintf(gpTextureFile, "Fragment shader logs : %s \n", szBuffer);
				free(szBuffer);
			}
		}
	}

	//Shader program
	//create
	TX_gShaderProgramObject = glCreateProgram();

	//attach vertext shader to shader program
	glAttachShader(TX_gShaderProgramObject, TX_gVertexShaderObject);
	//attach fragment shader to shader program 
	glAttachShader(TX_gShaderProgramObject, TX_gFragmentShaderObject);

	//bind attribute with the one which we have specified with in in vertex shader
	glBindAttribLocation(TX_gShaderProgramObject, TX_ATTRIBUTE_POSITION, "vPosition");
	// 
	glBindAttribLocation(TX_gShaderProgramObject, TX_ATTRIBUTE_TEXCOORD, "vTexcord");

	//link shader
	glLinkProgram(TX_gShaderProgramObject);
	//linking error cheking code
	GLint shaderProgramLinkStatus = 0;
	szBuffer = NULL;
	glGetProgramiv(TX_gShaderProgramObject, GL_LINK_STATUS, &shaderProgramLinkStatus);
	if (shaderProgramLinkStatus == GL_FALSE) {
		glGetProgramiv(TX_gShaderProgramObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0) {
			szBuffer = (char*)malloc(infoLogLength);
			if (szBuffer != NULL) {
				GLint written;
				glGetProgramInfoLog(TX_gShaderProgramObject, infoLogLength, &written, szBuffer);
				//print log to file
				fprintf(gpTextureFile, "Fragment shader logs : %s \n", szBuffer);
				free(szBuffer);
			}
		}
	}

	//get MVP uniform location 
	TX_mvpMatrixUniform = glGetUniformLocation(TX_gShaderProgramObject, "u_mvpMatrix");
	TX_fdfoUniform = glGetUniformLocation(TX_gShaderProgramObject, "alpha");

	const GLfloat quadVertices[] = {
		//front
		-1.0f, 1.0f, 0.0f,
		-1.0f, -1.0f, 0.0f,
		1.0f, -1.0f, 0.0f,
		1.0f, 1.0f, 0.0f
	};

	glGenVertexArrays(1, &TX_vao); //?
	glBindVertexArray(TX_vao); //?

	//push this vector array to shader
	glGenBuffers(1, &TX_vboPos);
	glBindBuffer(GL_ARRAY_BUFFER, TX_vboPos);//bind vbo with buffer array
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadVertices), quadVertices, GL_STATIC_DRAW); //add vertex data

	glVertexAttribPointer(TX_ATTRIBUTE_POSITION, 3, GL_FLOAT, GL_FALSE, 0, NULL); //map data 
	glEnableVertexAttribArray(TX_ATTRIBUTE_POSITION); //enable the mapped buffer

	glBindBuffer(GL_ARRAY_BUFFER, 0);//unbind
	/*
	const GLfloat quadColor[] = {
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f
	};

	//push this color array to shader
	glGenBuffers(1, &TX_vboColor);
	glBindBuffer(GL_ARRAY_BUFFER, TX_vboColor);//bind vbo with buffer array
	glBufferData(GL_ARRAY_BUFFER, sizeof(quadColor), quadColor, GL_STATIC_DRAW);//add color data

	glVertexAttribPointer(TX_ATTRIBUTE_COLOR, 3, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray(TX_ATTRIBUTE_COLOR);

	glBindBuffer(GL_ARRAY_BUFFER, 0); //unbind

	glBindVertexArray(0);*/

	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	//glEnable(GL_CULL_FACE);

	//texture
	LoadGLTextureCredits(&TX_texture1, MAKEINTRESOURCE(ENDCREDIT1));
	LoadGLTextureCredits(&TX_texture2, MAKEINTRESOURCE(ENDCREDIT2));
	LoadGLTextureCredits(&TX_texture3, MAKEINTRESOURCE(ENDCREDIT3));
}



void RenderQuadWithTexture(vmath::mat4 perspectiveProjectionMatrix , float alpha ,int creditScene) {
	//start using opengl program object
	glUseProgram(TX_gShaderProgramObject);
	GLfloat texCoord[8] = { 0.0f,1.0f,0.0f,0.0f,1.0f,0.0f,1.0f,1.0f };

	//OpenGL drawing
	//set modelview and projection matrix to dentity 
	vmath::mat4 modelViewMatrix = vmath::mat4::identity();
	vmath::mat4 modelViewprojectionMatrix = vmath::mat4::identity();
	vmath::mat4 translationMatrix = vmath::mat4::identity();
	vmath::mat4 scaleMatrix = vmath::mat4::identity();

	translationMatrix = vmath::translate(0.0f, 0.0f, -3.0f);
	scaleMatrix = vmath::scale(2.2f,1.5f,1.0f);

	modelViewMatrix = translationMatrix* scaleMatrix;
	modelViewprojectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;

	glUniformMatrix4fv(TX_mvpMatrixUniform, 1, GL_FALSE, modelViewprojectionMatrix);
	//push to shader ^
	glActiveTexture(GL_TEXTURE0);
	switch (creditScene) {
	case 1:
		glBindTexture(GL_TEXTURE_2D, TX_texture3); //
		break;
	case 2:
		glBindTexture(GL_TEXTURE_2D, TX_texture1); //
		break;
	case 3:
		glBindTexture(GL_TEXTURE_2D, TX_texture2); //
		break;
	}

	glUniform1i(TX_textureSamplerUnifirm, 0);
	glUniform1f(TX_fdfoUniform, alpha);

	//push to shader ^

	glBindVertexArray(TX_vao); //bind vao

	glEnable(GL_TEXTURE_2D);
	//push this texture array to shader
	glGenBuffers(1, &TX_vboTexture);
	glBindBuffer(GL_ARRAY_BUFFER, TX_vboTexture);//bind vbo with buffer array
	//TODO add color data foe showing white colored square
	glBufferData(GL_ARRAY_BUFFER, sizeof(texCoord), texCoord, GL_DYNAMIC_DRAW);

	glVertexAttribPointer(TX_ATTRIBUTE_TEXCOORD, 2, GL_FLOAT, GL_FALSE, 0, NULL); //map data 
	glEnableVertexAttribArray(TX_ATTRIBUTE_TEXCOORD); //enable the mapped buffer

	glBindBuffer(GL_ARRAY_BUFFER, 0); //unbind
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	glBindVertexArray(0); //unbind vao

	//stop using program
	glUseProgram(0);
}

void UnInitializeQuadWithTexture() {
	if (TX_vao) {
		glDeleteVertexArrays(1, &TX_vao);
		TX_vao = 0;
	}
	if (TX_vboPos) {
		glDeleteBuffers(1, &TX_vboPos);
		TX_vboPos = 0;
	}
	if (TX_vboColor) {
		glDeleteBuffers(1, &TX_vboColor);
		TX_vboColor = 0;
	}
	//safe release changes
	if (TX_gShaderProgramObject) {
		glUseProgram(TX_gShaderProgramObject);
		//shader cound to shaders attached to shader prog object
		GLsizei shaderCount;
		glGetProgramiv(TX_gShaderProgramObject, GL_ATTACHED_SHADERS, &shaderCount);
		GLuint* pShaders;
		pShaders = (GLuint*)malloc(sizeof(GLuint) * shaderCount);
		if (pShaders == NULL) {
			fprintf(gpTextureFile, "Failed to allocate memory for pShaders");
			return;
		}
		//1st shader count is expected value we are passing and 2nd variable we are passing address in which
		//we are getting actual shader count currently attached to shader prog 
		glGetAttachedShaders(TX_gShaderProgramObject, shaderCount, &shaderCount, pShaders);
		for (GLsizei i = 0; i < shaderCount; i++) {
			glDetachShader(TX_gShaderProgramObject, pShaders[i]);
			glDeleteShader(pShaders[i]);
			pShaders[i] = 0;
		}
		free(pShaders);
		glDeleteProgram(TX_gShaderProgramObject);
		TX_gShaderProgramObject = 0;
		glUseProgram(0);
	}

}