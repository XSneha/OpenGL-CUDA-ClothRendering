#pragma once

#define MYICON				 201
#define CLOTH_BITMAP_1		 202
#define CLOTH_BITMAP_2		 203
#define CLOTH_BITMAP_3		 204
#define CLOTH_BITMAP_4		 205
#define CLOTH_BITMAP_5		 206
#define CLOTH_BITMAP_6		 207
#define MYMUSIC				 208
#define ENDCREDIT1			 209
#define ENDCREDIT2			 210
#define ENDCREDIT3			 211

